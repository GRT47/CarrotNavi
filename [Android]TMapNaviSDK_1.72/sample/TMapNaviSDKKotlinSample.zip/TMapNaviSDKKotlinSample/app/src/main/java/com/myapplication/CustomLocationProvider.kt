package com.myapplication

import android.location.Location
import android.os.Handler
import com.skt.tmap.engine.navigation.SDKLocationProvider
import com.skt.tmap.engine.navigation.location.DEFAULT_LATITUDE
import com.skt.tmap.engine.navigation.location.DEFAULT_LONGITUDE
import com.skt.tmap.engine.navigation.location.LocationProviderListener
import com.skt.tmap.engine.navigation.location.OnErrorListener
import com.skt.tmap.engine.navigation.util.setSatelliteCount

class CustomLocationProvider : SDKLocationProvider() {
    companion object {
        const val NAME = "custom" // Provider 식별자
    }

    private lateinit var listener: LocationProviderListener

    // locationThreadLooper는 SDK 초기화 중 Navigation SDK가 주입합니다.
    private val handler: Handler? get() = locationThreadLooper?.let { Handler(it) }

    override fun requestUpdateOnce() {
        // 위치 데이터 1회 제공
        Location(NAME).apply {
            latitude = DEFAULT_LATITUDE
            longitude = DEFAULT_LONGITUDE
            accuracy = 5f
            speed = 10f
            bearing = 180f
            time = System.currentTimeMillis()
            setSatelliteCount(4)

            // 위치 변경 이벤트 발생
            handler?.post { listener.onLocationChanged(this) }
        }
    }

    override fun requestUpdate(intervalTime: Int) {
        // intervalTime을 기준으로 주기적으로 위치 데이터 제공
    }

    override fun removeLocationUpdates() {
        // Location Provider를 release하는 작업 수행
    }

    // 아래 내용은 그대로 사용합니다.
    override fun initializeProvider(listener: LocationProviderListener) {
        this.listener = listener
    }

    override fun stop() {
        removeLocationUpdates()
    }

    override fun getName(): String = NAME // SDK에서 Provider 구분 시 식별자로 사용합니다.

    override fun turnOnGPS() {}

    override fun setErrorListener(errorListener: OnErrorListener) {}
}
