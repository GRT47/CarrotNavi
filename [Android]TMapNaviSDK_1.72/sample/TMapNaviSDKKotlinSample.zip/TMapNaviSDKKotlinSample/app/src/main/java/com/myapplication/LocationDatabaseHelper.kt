package com.myapplication

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.location.Location

class LocationDatabaseHelper(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                longitude REAL,
                latitude REAL,
                bearing REAL,
                speed REAL,
                time_sec TEXT,
                satellite_count INTEGER,
                method TEXT,
                accuracy REAL,
                map_match_code TEXT,
                map_match_lng TEXT,
                map_match_lat TEXT,
                map_match_bearing TEXT,
                real_time TEXT,
                altitude REAL,
                vertical_angle INTEGER,
                provider TEXT,
                activity_type INTEGER,
                time_ms INTEGER
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVer: Int, newVer: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertLocation(
        location: Location,
        satelliteCount: Int,
        provider: String?
    ) {
        writableDatabase.use { db ->
            ContentValues().apply {
                put("longitude", location.longitude)
                put("latitude", location.latitude)
                put("bearing", location.bearing)
                put("speed", location.speed)
                put("time_sec", "")
                put("satellite_count", satelliteCount)
                put("method", "")
                put("accuracy", location.accuracy)
                put("map_match_code", "")
                put("map_match_lng", "")
                put("map_match_lat", "")
                put("map_match_bearing", "")
                put("real_time", "")
                put("altitude", location.altitude)
                put("vertical_angle", 0)
                put("provider", provider)
                put("activity_type", 0)
                put("time_ms", location.time)

                db.insert(TABLE_NAME, null, this)
            }
        }
    }

    val allRows: Cursor get() = readableDatabase.query(TABLE_NAME, null, null, null, null, null, "id ASC")

    fun deleteAll() = writableDatabase.delete(TABLE_NAME, null, null)

    companion object {
        private const val DATABASE_NAME = "locations.db"
        private const val DATABASE_VERSION = 1
        const val TABLE_NAME = "location_log"
    }
}
