package com.myapplication

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.GnssStatus
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Observer
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.skt.tmap.engine.navigation.SDKManager
import com.skt.tmap.engine.navigation.data.TruckType
import com.skt.tmap.engine.navigation.network.ndds.CarOilType
import com.skt.tmap.engine.navigation.network.ndds.NddsDataType.DestSearchFlag
import com.skt.tmap.engine.navigation.network.ndds.TollCarType
import com.skt.tmap.engine.navigation.route.RoutePlanType
import com.skt.tmap.engine.navigation.route.RouteResult
import com.skt.tmap.engine.navigation.route.data.MapPoint
import com.skt.tmap.engine.navigation.route.data.WayPoint
import com.skt.tmap.vsm.coordinates.VSMCoordinates
import com.skt.tmap.vsm.data.VSMMapPoint
import com.skt.tmap.vsm.location.LocationComponent
import com.skt.tmap.vsm.map.MapEngine.OnHitCalloutPopupListener
import com.skt.tmap.vsm.map.MapEngine.OnHitObjectListener
import com.skt.tmap.vsm.map.marker.MarkerImage
import com.skt.tmap.vsm.map.marker.VSMMarkerBase
import com.skt.tmap.vsm.map.marker.VSMMarkerPoint
import com.tmapmobility.tmap.tmapsdk.ui.data.CarOption
import com.tmapmobility.tmap.tmapsdk.ui.data.LocationInitParam
import com.tmapmobility.tmap.tmapsdk.ui.data.MapSetting
import com.tmapmobility.tmap.tmapsdk.ui.data.MapViewMode
import com.tmapmobility.tmap.tmapsdk.ui.data.NavigationScreenState
import com.tmapmobility.tmap.tmapsdk.ui.data.NavigationScreenState.AndoScreen
import com.tmapmobility.tmap.tmapsdk.ui.data.NavigationScreenState.DefaultScreen
import com.tmapmobility.tmap.tmapsdk.ui.data.NavigationScreenState.NavigationScreen
import com.tmapmobility.tmap.tmapsdk.ui.data.NavigationScreenState.RouteSummaryScreen
import com.tmapmobility.tmap.tmapsdk.ui.data.NavigationScreenState.SelectRouteScreen
import com.tmapmobility.tmap.tmapsdk.ui.data.NavigationScreenState.SimulationScreen
import com.tmapmobility.tmap.tmapsdk.ui.data.NavigationScreenStateListener
import com.tmapmobility.tmap.tmapsdk.ui.data.ObservableRouteData
import com.tmapmobility.tmap.tmapsdk.ui.data.RouteGuidanceConfig
import com.tmapmobility.tmap.tmapsdk.ui.data.TruckInfoKey
import com.tmapmobility.tmap.tmapsdk.ui.data.UIVisibleOption
import com.tmapmobility.tmap.tmapsdk.ui.fragment.NavigationFragment
import com.tmapmobility.tmap.tmapsdk.ui.util.TmapUISDK
import com.tmapmobility.tmap.tmapsdk.ui.util.TmapUISDK.Companion.getFragment
import com.tmapmobility.tmap.tmapsdk.ui.util.TmapUISDK.Companion.initialize
import com.tmapmobility.tmap.tmapsdk.ui.util.TmapUISDK.DrivingStatusCallback
import com.tmapmobility.tmap.tmapsdk.ui.util.TmapUISDK.InitializeListener
import com.tmapmobility.tmap.tmapsdk.ui.util.TmapUISDK.RouteRequestListener
import com.tmapmobility.tmap.tmapsdk.ui.view.MapConstant
import com.tmapmobility.tmap.tmapsdk.ui.view.VsmSdkMapView
import java.io.File
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.concurrent.Volatile

class MainActivity : AppCompatActivity() {
    private lateinit var navigationFragment: NavigationFragment
    private lateinit var fragmentManager: FragmentManager

    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var button3: Button
    private lateinit var button4: Button
    private lateinit var button5: Button
    private lateinit var button6: Button
    private lateinit var button7: Button
    private lateinit var button8: Button
    private lateinit var button9: Button
    private lateinit var stopButton: Button
    private lateinit var changeViewModeButton: Button
    private var viewMode = 0

    private lateinit var buttonLayout: LinearLayout

    var isEDC = false // edc 수신 여부
    var isRoute = false // route data 수신 여부

    private var fusedLocationClient: FusedLocationProviderClient? = null
    private var locationCallback: LocationCallback? = null
    private var locationManager: LocationManager? = null
    private var gnssStatusCallback: GnssStatus.Callback? = null

    private var isLocationUpdating = false
    private var isGnssCallbackRegistered = false

    @Volatile
    private var satelliteCount = 0

    val dbHelper by lazy { LocationDatabaseHelper(this) }

    var isAuthorized = false

    private val buttonActions = mapOf(
        R.id.button1 to ::clickButton1,
        R.id.button2 to ::clickButton2,
        R.id.button3 to ::clickButton3,
        R.id.button4 to ::clickButton4,
        R.id.button5 to ::clickButton5,
        R.id.button6 to ::clickButton6,
        R.id.button7 to ::clickButton7,
        R.id.button8 to ::clickButton8,
        R.id.button9 to ::clickButton9
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkPermission()
    }

    private fun checkPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        ) {
            initUI()
            initUISDK()
            setLocation()
        } else {
            val permissionArr = arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            requestPermissions(permissionArr, 100)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == 100 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
            initUI()
            initUISDK()
        } else {
            Toast.makeText(this, "위치 권한이 없습니다.", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun initUI() {
        fragmentManager = supportFragmentManager
        navigationFragment = getFragment()

        fragmentManager.beginTransaction()
            .add(R.id.tmapUILayout, navigationFragment)
            .commitAllowingStateLoss()

        buttonLayout = findViewById(R.id.buttonLayout)

        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)
        button3 = findViewById(R.id.button3)
        button4 = findViewById(R.id.button4)
        button5 = findViewById(R.id.button5)
        button6 = findViewById(R.id.button6)
        button7 = findViewById(R.id.button7)
        button8 = findViewById(R.id.button8)
        button9 = findViewById(R.id.button9)

        listOf(button1, button2, button3, button4, button5, button6, button7, button8, button9).forEach {
            it.setOnClickListener(onClickButton)
        }

        stopButton = findViewById<Button>(R.id.stopButton).apply {
            setOnClickListener(onClickButton)
            visibility = View.GONE
        }

        changeViewModeButton = findViewById<Button>(R.id.changeViewModeButton).apply {
            setOnClickListener(onClickButton)
            visibility = View.GONE
        }

        isEDC = false

        // 야간 모드 상태 수신
        navigationFragment.nightModeLiveData.observe(this) { isNight ->
            Log.d("isNight", "night mode changed: $isNight")
        }

        // 네비게이션 상태 변경 시 callback
        navigationFragment.drivingStatusCallback = object : DrivingStatusCallback {
            override fun onStartNavigationInfo(
                totalDistanceInMeter: Int,
                totalTimeInSec: Int,
                tollFee: Int
            ) {
                //경로 시작 정보
                Log.d(TAG, "onStartNavigationInfo $totalDistanceInMeter::$totalTimeInSec::$tollFee")

                val routeResult = TmapUISDK.getRouteResult()
                val formatted = TIMESTAMP_FORMATTER.format(LocalDateTime.now())
                saveRouteResultToDownloads(this@MainActivity, "routeResult_$formatted.json", routeResult)

                setLocation()
            }

            override fun onUserRerouteComplete() {
                // 사용자 재탐색 동작 완료 시 호출
                Log.e(TAG, "onUserRerouteComplete")
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onUserRerouteComplete",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onStartNavigation() {
                // 네비게이션 시작 시 호출

                Log.e(TAG, "onStartNavigation")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onStartNavigation",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onStopNavigation() {
                exportCsvFromDb(this@MainActivity)

                // 네비게이션 종료 시 호출
                buttonLayout.visibility = View.VISIBLE
                stopButton.visibility = View.GONE
                changeViewModeButton.visibility = View.GONE
                Log.e(TAG, "onStopNavigation")
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onStopNavigation",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onTryToStopNavigation(): Boolean {
                /**
                 * 경로 종료를 별도의 UI로 처리할 경우
                 * false 반환 시 SDK의 종료 버튼을 선택해도 종료 동작을 수행하지 않음
                 * 별도의 ui로 navigation 종료
                 * MapSetting setShowClosedPopup(true) 설정 필요
                 */
                val builder = AlertDialog.Builder(this@MainActivity)
                val message = "경로 안내를 종료하시겠습니까?"

                builder.setMessage(message)
                    .setPositiveButton(
                        "네"
                    ) { dialog, which -> navigationFragment.stopDrive() }
                    .setNegativeButton(
                        "아니오"
                    ) { dialog, which -> }
                    .show()
                return false
            }

            override fun onRouteChanged(index: Int) {
                // 경로 변경 완료 시 호출
                Log.e(TAG, "onRouteChanged $index")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onRouteChanged",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onRouteOptionChanged(
                originalOption: RoutePlanType,
                changedOption: RoutePlanType
            ) {
                // 경로 옵션 변경 시 호출
                Log.e(TAG, "onRouteOptionChanged")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onRouteOptionChanged",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onPermissionDenied(errorCode: Int, errorMsg: String?) {
                // 권한 에러 발생 시 호출
                Log.e(TAG, "onPermissionDenied $errorCode::$errorMsg")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onPermissionDenied",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onPeriodicRerouteComplete() {
                // 정주기 재탐색 동작 완료 시 호출
                Log.e(TAG, "onPeriodicRerouteComplete")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onPeriodicRerouteComplete",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onPeriodicReroute() {
                // 정주기 재탐색 발생 시점에 호출
                Log.e(TAG, "onPeriodicReroute")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onPeriodicReroute",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onPassedViaPoint() {
                // 경유지 통과 시 호출
                Log.e(TAG, "onPassedViaPoint")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onPassedViaPoint",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onPassedTollgate(fee: Int) {
                // 톨게이트 통과 시 호출
                // i 요금

                Log.e(TAG, "onPassedTollgate $fee")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onPassedTollgate",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onPassedAlternativeRouteJunction() {
                // 대안 경로 통과 시 호출
                Log.e(TAG, "onPassedAlternativeRouteJunction")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onPassedAlternativeRouteJunction",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onNoLocationSignal(noLocationSignal: Boolean) {
                // GPS 상태 변화 시점에 호출
                Log.e(
                    TAG,
                    "onPassedAlternativeRouteJunction :: $noLocationSignal"
                )

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onNoLocationSignal $noLocationSignal", Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onLocationChanged() {
                //위치 갱신 때 마다 호출
                Log.e(TAG, "onLocationChanged")
            }

            override fun onFailRouteRequest(errorCode: String, errorMessage: String) {
                //경로 탐색 실패 시 호출
                Log.e(
                    TAG,
                    "onFailRouteRequest $errorCode::$errorMessage"
                )

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onFailRouteRequest",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onDoNotRerouteToDestinationComplete() {
                //미리 종료 안내 동작 탐색 완료 시점에 호출
                Log.e(TAG, "onDoNotRerouteToDestinationComplete")
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onDoNotRerouteToDestinationComplete",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onDestinationDirResearchComplete() {
                // 건너편 안내 동작 탐색 완료 시점에 호출
                Log.e(TAG, "onDestinationDirResearchComplete")
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onDestinationDirResearchComplete",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onChangeRouteOptionComplete(routePlanType: RoutePlanType) {
                // 경로 옵션 변경 완료 시 호출
                Log.e(TAG, "onChangeRouteOptionComplete")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onChangeRouteOptionComplete",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onBreakawayFromRouteEvent() {
                // 경로 이탈 재탐색 발생 시점에 호출
                Log.e(TAG, "onBreakawayFromRouteEvent")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onBreakawayFromRouteEvent",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onBreakAwayRequestComplete() {
                //경로 이탈 재탐색 동작 완료 시점에 호출
                Log.e(TAG, "onBreakAwayRequestComplete")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onBreakAwayRequestComplete",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onArrivedDestination(
                destination: String,
                drivingTime: Int,
                drivingDistance: Int
            ) {
                // 목적지 도착 시 호출
                // dest 목적지 명
                // drivingTime 운전시간
                // drivingDistance 운전거리

                Log.e(TAG, "onArrivedDestination")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onArrivedDestination",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onApproachingViaPoint() {
                // 경유지 접근 시점에 호출 (1km 이내)
                Log.e(TAG, "onApproachingViaPoint")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onApproachingViaPoint",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onApproachingAlternativeRoute() {
                // 대안 경로 접근 시 호출
                Log.e(TAG, "onApproachingAlternativeRoute")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onApproachingAlternativeRoute",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onForceReroute(periodicType: DestSearchFlag) {
                // 경로 재탐색 발생 시점에 호출
                Log.e(TAG, "onForceReroute")

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "onForceReroute",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        // 화면 상태 수신
        navigationFragment.setNavigationScreenStateListener(object : NavigationScreenStateListener {
            override fun onChanged(state: NavigationScreenState) {
                val screenType = when (state) {
                    is DefaultScreen -> "기본 화면"
                    is SelectRouteScreen -> "경로 선택 화면"
                    is AndoScreen -> "안심 주행 화면"
                    is NavigationScreen -> "길 안내 화면"
                    is SimulationScreen -> "모의 주행 화면"
                    is RouteSummaryScreen -> "전체 경로 요약 화면"
                    else -> "알 수 없는 상태"
                }
                Log.d(TAG, screenType)
            }
        })

        observeJammingZone()
    }

    private val onClickButton = View.OnClickListener { v ->
        buttonActions[v.id]?.let { action ->
            if (!isAuthorized) {
                Toast.makeText(this, "인증 완료 후, 이용 가능합니다.", Toast.LENGTH_SHORT).show()
                return@OnClickListener
            }

            action()
            return@OnClickListener
        }

        when (v.id) {
            R.id.stopButton -> navigationFragment.stopDrive()

            R.id.changeViewModeButton -> {
                val mapMode = when (viewMode) {
                    0 -> MapViewMode.DEFAULT
                    1 -> MapViewMode.NORTH_BOUND
                    2 -> MapViewMode.HEAD_UP_2D
                    else -> MapViewMode.BIRD_VIEW_3D
                }

                navigationFragment.applyMapViewMode(mapMode)

                navigationFragment.getCurrentMapViewMode()?.name?.let {
                    Log.d(TAG, it)
                }
                Log.d(TAG, "view mode: $viewMode")

                viewMode = (viewMode + 1) % 4
            }
        }
    }

    private fun defaultCarOption(oilType: CarOilType = CarOilType.PremiumGasoline) = CarOption().apply {
        carType = TollCarType.Car
        this.oilType = oilType
        isHipassOn = true
    }

    /**
     * 안전운행
     */
    private fun clickButton1() {
        buttonLayout.visibility = View.GONE
        stopButton.visibility = View.VISIBLE
        navigationFragment.startSafeDrive()
    }

    /**
     * 경로안내
     */
    private fun clickButton2() {
        buttonLayout.visibility = View.GONE
        changeViewModeButton.visibility = View.VISIBLE

        val carOption = defaultCarOption()

        // 현재 위치 설정
        SDKManager.getInstance().requestCurrentLocation { currentLocation ->
            val currentName = VSMCoordinates.getAddressOffline(currentLocation.longitude, currentLocation.latitude)
            val startPoint = WayPoint(currentName, MapPoint(currentLocation.longitude, currentLocation.latitude))

            // 목적지 설정
            val endPoint = GANGNAM_STATION

            // 네비게이션 옵션 설정
            navigationFragment.carOption = carOption

            // 경로 계획 유형 설정
            val planTypeList = arrayListOf(
                RoutePlanType.Traffic_Recommend,
                RoutePlanType.Traffic_Free
            )

            runOnUiThread {
                // 경로안내 요청
                navigationFragment.requestRoute(
                    startPoint,
                    null,
                    endPoint,
                    false,
                    object : RouteRequestListener {
                        override fun onSuccess() {
                            Log.e(TAG, "requestRoute Success")
                            stopButton.visibility = View.VISIBLE
                        }

                        override fun onFail(errorCode: Int, errorMsg: String?) {
                            val errorMessage = "Route request failed: $errorCode - ${errorMsg ?: "Unknown error"}"
                            Toast.makeText(this@MainActivity, errorMessage, Toast.LENGTH_SHORT).show()
                            Log.e(TAG, "onFail $errorCode :: $errorMsg")
                        }
                    },
                    planTypeList
                )
            }
        }
    }

    /**
     * 경유지 추가 경로안내
     */
    private fun clickButton3() {
        buttonLayout.visibility = View.GONE

        val carOption = defaultCarOption(CarOilType.Gasoline)

        SDKManager.getInstance().requestCurrentLocation { currentLocation ->
            val currentName = VSMCoordinates.getAddressOffline(currentLocation.longitude, currentLocation.latitude)
            val startPoint = WayPoint(currentName, MapPoint(currentLocation.longitude, currentLocation.latitude))

            val passList = ArrayList<WayPoint>().apply {
                add(WayPoint("가", MapPoint(126.9628, 37.5382)))
                add(WayPoint("나", MapPoint(126.9385, 37.5199)))
                add(WayPoint("다", MapPoint(126.9620, 37.5223)))
            }

            val endPoint = GANGNAM_STATION_WITH_POI.apply {
                setCenterPoint(127.028113, 37.5)
            }

            navigationFragment.carOption = carOption

            val planTypeList = arrayListOf(
                RoutePlanType.Traffic_Recommend,
                RoutePlanType.Traffic_Free
            )

            runOnUiThread {
                navigationFragment.requestRoute(
                    startPoint,
                    passList,
                    endPoint,
                    false,
                    object : RouteRequestListener {
                        override fun onSuccess() {
                            Log.e(TAG, "requestRoute Success")
                            stopButton.visibility = View.VISIBLE
                        }

                        override fun onFail(errorCode: Int, errorMsg: String?) {
                            Toast.makeText(this@MainActivity, "$errorCode::$errorMsg", Toast.LENGTH_SHORT).show()
                            Log.e(TAG, "onFail $errorCode :: $errorMsg")
                        }
                    },
                    planTypeList
                )
            }
        }
    }

    private fun clickButton4() {
        buttonLayout.visibility = View.GONE

        val carOption = defaultCarOption().apply {
            // 트럭 경로 요청 정보
            truckInfo = hashMapOf(
                TruckInfoKey.TruckType.value to TruckType.Truck.toString(),
                TruckInfoKey.TruckWeight.value to "2000.0",
                TruckInfoKey.TruckHeight.value to "400.0"
            )
        }

        SDKManager.getInstance().requestCurrentLocation { currentLocation ->
            val currentName = VSMCoordinates.getAddressOffline(currentLocation.longitude, currentLocation.latitude)
            val startPoint = WayPoint(currentName, MapPoint(currentLocation.longitude, currentLocation.latitude))
            val endPoint = GANGNAM_STATION_WITH_POI

            navigationFragment.carOption = carOption

            val planTypeList = arrayListOf(
                RoutePlanType.Traffic_Recommend,
                RoutePlanType.Traffic_Highway
            )

            runOnUiThread {
                navigationFragment.requestRoute(
                    startPoint,
                    null,
                    endPoint,
                    true,
                    object : RouteRequestListener {
                        override fun onSuccess() {
                            Log.e(TAG, "requestRoute Success")
                            stopButton.visibility = View.VISIBLE
                        }

                        override fun onFail(errorCode: Int, errorMsg: String?) {
                            Toast.makeText(this@MainActivity, "$errorCode::$errorMsg", Toast.LENGTH_SHORT).show()
                            Log.e(TAG, "onFail $errorCode :: $errorMsg")
                        }
                    },
                    planTypeList
                )
            }
        }
    }

    /**
     * 즐겨찾기 경로 안내
     */
    private fun clickButton5() {
        buttonLayout.visibility = View.GONE

        val carOption = defaultCarOption(CarOilType.Gasoline)

        //현재 위치
        SDKManager.getInstance().requestCurrentLocation { currentLocation ->
            val currentName =
                VSMCoordinates.getAddressOffline(currentLocation.longitude, currentLocation.latitude)
            val startPoint =
                WayPoint(currentName, MapPoint(currentLocation.longitude, currentLocation.latitude))

            //목적지
            val endPoint = WayPoint("", MapPoint(126.78933292570062, 37.63989758960467))

            navigationFragment.carOption = carOption

            // 기존에 탐색했던 경로 데이터
            val preferredRouteInfo =
                "45716560,13522554:260,25:-1,44:267,68:15,-110:43,-238:-266,-45:-89,-18:-51,-11:-107,-24:-275,-11:-27,81:-9,194:-10,274:-72,28:-368,-15:-200,-7:-35,-1:-67,-3:-401,-1:-129,-1:-197,2:-50,-3:-238,-15:-67,-3:-174,-9:-202,2:-330,-1:-19,0:-321,2:-119,3:-108,2:-50,-82:-94,-199:-68,-106:-309,-12:-104,-1:-96,-12:-47,-184:-137,-107:-594,-226:-293,-105:-192,-62:-173,-39:-190,-40:-142,-29:-108,-53:-2018,-605:-101,-52:-354,-218:-139,-79:-324,-170:-40,-13:-14,-3:-225,-19:-380,-17:-328,-259:-205,-161:-271,-209:-17,-13:-105,-86:-21,-17:-129,-101:-74,-59:-306,-274:-228,-442:-23,-47:-22,-43:-22,-44:-201,-415:-129,-256:-27,-54:-103,-207:-194,-392:-27,-52:-66,-134:-92,-203:-72,-133:-26,-54:-19,-43:-72,-154:-182,-311:-185,-256:-42,-56:-106,-138:-319,-430:-69,-92:-258,-363:-137,-187:-83,-122:-182,-207:-126,-102:-152,-110:-254,-184:-35,-23:-466,-335:-229,-169:-136,-99:-191,-141:-122,-84:-57,-39:-36,-25:-15,-11:-118,-61:-835,-173:-339,144:-65,45:-1144,1009:-85,40:-2682,568:-602,244:-867,255:-94,9:-387,0:-298,-41:-514,-151:-1680,-483:-445,79:-2157,892:-686,484:-109,84:-1000,667:-523,351:-555,412:-176,132:-316,235:-198,143:-1191,881:-1584,1460:-175,160:-1076,689:-655,379:-286,163:-885,497:-670,387:-658,377:-257,149:-1011,584:-1420,823:-117,68:-60,35:-714,415:-888,517:-1290,744:-1552,905:-159,96:-594,329:-1706,975:-633,356:-451,260:-583,336:-454,263:-479,274:-796,460:-255,155:-1766,1009:-883,583:-243,233:-631,795:-92,122:-96,122:-220,285:-457,583:-203,259:-540,694:-2116,1271:-275,73:-632,170:-217,61:-68,16:-208,55:-743,200:-1468,460:-2167,1869:-610,451:-477,313:-848,860:-108,1271:54,122:157,187:640,1274:86,660:6,85:10,176:99,1546:6,103:20,307:3,35:-931,1318:-1267,180:-1300,313:-280,214"

            runOnUiThread {
                // 즐겨 찾는 경로 안내
                navigationFragment.requestUserFavoriteRoute(
                    startPoint,
                    null,
                    endPoint,
                    false,
                    preferredRouteInfo,
                    object : RouteRequestListener {
                        override fun onSuccess() {
                            Log.e(TAG, "requestUserFavoriteRoute Success")
                            stopButton.visibility = View.VISIBLE
                        }

                        override fun onFail(errorCode: Int, errorMsg: String?) {
                            Toast.makeText(this@MainActivity, "$errorCode::$errorMsg", Toast.LENGTH_SHORT).show()
                            Log.e(TAG, "onFail $errorCode :: $errorMsg")
                        }
                    },
                    RoutePlanType.Traffic_Highway
                )
            }
        }
    }

    /**
     * 경유지 맥스
     */
    private fun clickButton6() {
        buttonLayout.visibility = View.GONE

        val carOption = defaultCarOption()

        SDKManager.getInstance().requestCurrentLocation { currentLocation ->
            val currentName = VSMCoordinates.getAddressOffline(currentLocation.longitude, currentLocation.latitude)
            val startPoint = WayPoint(currentName, MapPoint(currentLocation.longitude, currentLocation.latitude))
            val endPoint = GANGNAM_STATION_WITH_POI

            navigationFragment.carOption = carOption

            val planTypeList = arrayListOf(
                RoutePlanType.Traffic_Recommend,
                RoutePlanType.Traffic_Free
            )

            val wayPoints = ArrayList(TestWayPoint.point)

            runOnUiThread {
                navigationFragment.requestRoute(
                    startPoint,
                    wayPoints,
                    endPoint,
                    true,
                    object : RouteRequestListener {
                        override fun onSuccess() {
                            Log.e(TAG, "requestRoute Success")
                            stopButton.visibility = View.VISIBLE
                        }

                        override fun onFail(errorCode: Int, errorMsg: String?) {
                            Toast.makeText(this@MainActivity, "$errorCode::$errorMsg", Toast.LENGTH_SHORT).show()
                            Log.e(TAG, "onFail $errorCode :: $errorMsg")
                        }
                    },
                    planTypeList
                )
            }
        }
    }

    private fun clickButton7() {
        val markerID = "TEST"
        val icon = BitmapFactory.decodeResource(resources, R.drawable.poi)
        val marker = VSMMarkerPoint(markerID)

        marker.icon = MarkerImage.fromBitmap(icon)
        marker.showPriority = MapConstant.MarkerRenderingPriority.DEFAULT_PRIORITY.toFloat()
        marker.text = "TEST"

        //현재 위치 보다 조금 옆에 마커를 찍는다.
        SDKManager.getInstance().requestCurrentLocation { currentLocation ->
            val position = VSMMapPoint(
                currentLocation.longitude - 0.0002,
                currentLocation.latitude + 0.0002
            )
            marker.position = position

            val markerManager = navigationFragment.getMapView()?.markerManager
            if (markerManager == null) {
                Log.e(TAG, "마커 매니저 NULL")
                return@requestCurrentLocation
            }

            markerManager.removeMarker(markerID)
            markerManager.addMarker(marker)

            navigationFragment.setHitEventListener(
                object : OnHitObjectListener {
                    override fun OnHitObjectPOI(
                        s: String,
                        i: Int,
                        vsmMapPoint: VSMMapPoint,
                        bundle: Bundle
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectMarker(
                        vsmMarkerBase: VSMMarkerBase,
                        bundle: Bundle
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectOilInfo(
                        s: String,
                        i: Int,
                        vsmMapPoint: VSMMapPoint
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectTraffic(
                        s: String,
                        i: Int,
                        s1: String,
                        s2: String,
                        s3: String,
                        vsmMapPoint: VSMMapPoint
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectCctv(
                        s: String,
                        i: Int,
                        vsmMapPoint: VSMMapPoint,
                        bundle: Bundle
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectAlternativeRoute(
                        s: String,
                        vsmMapPoint: VSMMapPoint
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectRouteFlag(
                        s: String,
                        i: Int,
                        vsmMapPoint: VSMMapPoint
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectRouteLine(
                        s: String,
                        i: Int,
                        vsmMapPoint: VSMMapPoint
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectLocationComponent(
                        locationComponent: LocationComponent,
                        vsmMapPoint: VSMMapPoint
                    ): Boolean {
                        return false
                    }

                    override fun OnHitObjectNone(vsmMapPoint: VSMMapPoint): Boolean {
                        return false
                    }
                },

                object : OnHitCalloutPopupListener {
                    override fun OnHitCalloutPopupPOI(
                        s: String,
                        i: Int,
                        vsmMapPoint: VSMMapPoint,
                        bundle: Bundle
                    ) {
                    }

                    override fun OnHitCalloutPopupMarker(vsmMarkerBase: VSMMarkerBase) {
                    }

                    override fun OnHitCalloutPopupTraffic(
                        s: String,
                        i: Int,
                        s1: String,
                        s2: String,
                        s3: String,
                        vsmMapPoint: VSMMapPoint
                    ) {
                    }

                    override fun OnHitCalloutPopupCctv(
                        s: String,
                        i: Int,
                        vsmMapPoint: VSMMapPoint,
                        bundle: Bundle
                    ) {
                    }

                    override fun OnHitCalloutPopupUserDefine(
                        s: String,
                        i: Int,
                        vsmMapPoint: VSMMapPoint
                    ) {
                    }
                })
        }
    }


    private fun clickButton8() {
        subscribeEDCData()
    }


    private val edcListener = Observer<Bundle?> { bundle ->
        bundle?.let { Log.e(TAG, it.toString()) }
    }

    private fun subscribeEDCData() {
        if (isEDC) {
            isEDC = false
            TmapUISDK.observableEDCData.removeObserver(edcListener)
            button8.text = "EDC 수신 등록"
        } else {
            isEDC = true
            TmapUISDK.observableEDCData.observe(this, edcListener)
            button8.text = "EDC 수신 해제"
        }
    }

    private fun clickButton9() {
        subscribeRouteData()
    }

    private val routeDataListener = Observer<ObservableRouteData?> { data ->
        data?.let { routeData ->
            Log.e(TAG, routeData.toString())
            // 기본 정보
            val distance = routeData.nTotalDist // 목적지까지 총 남은거리(m)
            val time = routeData.nTotalTime // 목적지까지 총 남은 시간(초)
            val toll = routeData.tollFare // 톨게이트 요금
            val taxi = routeData.taxiFare // 택시 요금

            // 경로 좌표 데이터
            routeData.routeCoordinates?.firstOrNull()?.let { coord ->
                Log.e(TAG, "Coord: Lat=${coord.latitude}, Lon=${coord.longitude}")
            }

            // 경로 복잡도 정보
            routeData.routeTrafficInfos?.firstOrNull()?.let { trafficInfo ->
                Log.e(TAG, "Traffic: StartIndex=${trafficInfo.startIndexInCoordinate}, EndIndex=${trafficInfo.endIndexInCoordinate}")
            }

            // 도로 정보
            routeData.roadInfos?.firstOrNull()?.let { roadInfo ->
                val roadInfoStr = "RoadInfo: StartVtx=${roadInfo.startVtxIndex}, " +
                        "EndVtx=${roadInfo.endVtxIndex}, " +
                        "RoadType=${roadInfo.getRoadInfoRoadType()}, " +
                        "FacilityCode=${roadInfo.getRoadInfoFacilityCode()}, " +
                        "Length=${roadInfo.roadLengthInMeter}, " +
                        "MaxSpeed=${roadInfo.maxSpeedKmh}"
                Log.e(TAG, roadInfoStr)
            }

            // 턴 정보 요약
            routeData.turnInfos?.firstOrNull()?.let { turnInfo ->
                Log.e(TAG, "TurnInfo: ${turnInfo.turnPoint}, TurnCode=${turnInfo.turnCode}")
            }

            // 안내점 턴 정보
            routeData.guidePoints?.firstOrNull()?.let { guidePoint ->
                Log.e(TAG, "GuidePoint: ${guidePoint.turnPoint}, TurnCode=${guidePoint.turnCode}")
            }
        }
    }

    private fun subscribeRouteData() {
        if (isRoute) {
            isRoute = false
            TmapUISDK.observableRouteData.removeObserver(routeDataListener)
            button9.text = "Route Data 수신 등록"
        } else {
            isRoute = true
            TmapUISDK.observableRouteData.observe(this, routeDataListener)
            button9.text = "Route Data 수신 해제"
        }
    }

    private fun initUISDK() {
        // 커스텀 위치 제공자 설정
        val customProvider = CustomLocationProvider()
        val locationInitParam = LocationInitParam(listOf(customProvider))

        // SDK 초기화
        initialize(
            this, 
            CLIENT_ID, 
            API_KEY, 
            USER_KEY, 
            DEVICE_KEY, 
            object : InitializeListener {
                override fun onSuccess() {
                    Log.e(TAG, "success initialize")

                    setupMapLongPressListener()

                    isAuthorized = true

                    // 맵 설정 구성
                    val setting = MapSetting().apply {
                        isShowClosedPopup = false // 종료 안내 팝업 미표출
                        // setMapLayerType(MapLayerType.Default) // 기본 Map Style
                        // setMapLayerType(MapLayerType.Aerial) // 항공 사진 Map Style
                    }

                    navigationFragment.setSettings(setting)

                    // 추가 설정 옵션
                    // setTmapSDKRGOption() // 음성 안내 설정
                    // setDrivingUIVisibility() // 경로안내 화면 레이아웃 on/off

                    // 정주기 재탐색 설정
                    TmapUISDK.setUsePeriodicReroute(applicationContext, true)

                    // 현재 위치 정보 로깅
                    navigationFragment.getMapView()?.locationManager?.lastLocation?.let { location ->
                        Log.d(TAG, "위치: 위도=${location.latitude}, 경도=${location.longitude}, 정확도=${location.accuracy}")
                    }

                    TmapUISDK.setGatewayHeaders(
                        "trace-id",
                        "session-id"
                    )
                }

                override fun onFail(errorCode: Int, errorMsg: String?) {
                    val message = "초기화 실패: $errorCode - ${errorMsg ?: "알 수 없는 오류"}"
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                    Log.e(TAG, "onFail $errorCode :: $errorMsg")
                }

                override fun savedRouteInfoExists(destinationName: String?) {
                    destinationName?.let {
                        Log.e(TAG, "목적지: $it")
                        showDialogContinueRoute(it)
                    }
                }
            }, 
            null // TmapUISDK 초기화 시 위치 정보를 제공하는 CustomLocationProvider를 설정하려면 null 대신 locationInitParam 입력
        )
    }

    private fun showDialogContinueRoute(dest: String) {
        val message = "$dest(으)로 경로 안내를 이어서 안내 받으시겠습니까?"

        AlertDialog.Builder(this).apply {
            setMessage(message)
            setCancelable(false)

            setPositiveButton("네") { _, _ ->
                buttonLayout.visibility = View.GONE
                stopButton.visibility = View.VISIBLE

                navigationFragment.continueDrive(true, object : RouteRequestListener {
                    override fun onSuccess() {
                        Log.e(TAG, "경로 계속 운행 성공")
                    }

                    override fun onFail(errorCode: Int, errorMsg: String?) {
                        Log.e(TAG, "경로 계속 운행 실패: ${errorMsg ?: "알 수 없는 오류"}")
                    }
                })
            }

            setNegativeButton("아니오") { _, _ -> 
                navigationFragment.clearContinueDriveInfo() 
            }

            show()
        }
    }

    // 음성 안내 설정
    private fun setTmapSDKRGOption() {
        TmapUISDK.setRouteGuidanceConfig(
            RouteGuidanceConfig(
                false,  // sectionSpeedCameraOverSpeed : 구간 과속 단속 초과 속도 경고음 발성 여부 설정
                true,  // signalSpeedCameraOverSpeed : 신호 과속 단속 초과 속도 경고음 발성 여부 설정
                false,  // fixedSpeedCameraOverSpeed : 고정식 과속 단속 초과 속도 경고음 발성 여부 설정
                true,  // mobileSpeedCameraOverSpeed : 이동식 과속 단속 초과 속도 경고음 발성 여부 설정
                false,  // boxSpeedCameraOverSpeed : 박스형 과속 단속 초과 속도 경고음 발성 여부 설정
                true,  // signalViolationEnforced : 신호 위반 단속 음성 안내 여부 설정
                false,  // cutInViolationEnforced : 끼어들기 단속 음성 안내 여부 설정
                true,  // parkingViolationEnforced : 주정차 위반 단속 음성 안내 여부 설정
                false,  // busLaneEnforced : 버스 전용 차로 위반 단속 음성 안내 여부 설정
                true,  // shoulderEnforced : 갓길 단속 음성 안내 여부 설정
                false,  // speedBump : 과속 방지턱 음성 안내 여부 설정
                true,  // schoolZone : 스쿨존 음성 안내 여부 설정
                false,  // accidentZone : 사고 다발 지역 음성 안내 여부 설정
                true,  // sharpCurve : 급커브 구간 음성 안내 여부 설정
                false,  // fogZone : 안개 구간 음성 안내 여부 설정
                true,  // trafficInfoCollection : 교통 정보 수집 구간 음성 안내 여부 설정
                false,  // sleepyShelter : 졸음 쉼터 음성 안내 여부 설정
                true,  // icyRoad : 결빙 위험 구간 음성 안내 여부 설정
                false,  // greenCameraEnforced : 녹색 카메라 음성 안내 여부 설정
                true,  // railroadCrossing : 철길 건널목 음성 안내 여부 설정
                false,  // floodWarning : 홍수, 침수 주의 구간 음성 안내 여부 설정
                true,  // landSlideRisk : 산사태, 낙석 주의 구간 음성 안내 여부 설정
                false,  // pedestrianPriorityRoad : 보행자 우선 도로 음성 안내 여부 설정
                false,  // detailCrossDirName : 방면 교차로 명칭 음성 안내 여부 설정
                true,  // currentRoadName : 현재 도로 명칭 음성 안내 여부 설정
                false,  // realtimeRouteChange : 실시간 경로 변경 음성 안내 여부 설정
                true,  // routeRecalculation : 경로 재탐색 음성 안내 여부 설정
                false,  // serviceArea : 휴게소 안내 음성 안내 여부 설정
                true,  // tollgateGuide : 요금소 음성 안내 여부 설정
                false,  // hiPassGuide : 하이패스 음성 안내 여부 설정
                true // gpsClockEnabled : 시보 음성 안내 여부 설정
            )
        )
    }

    // 경로안내 화면 레이아웃 on/off
    private fun setDrivingUIVisibility() {
        navigationFragment.setUIVisibleOption(
            UIVisibleOption(
                true,  // isTbtViewVisible : Turn 정보를 보여주는 TBT View
                true,  // isBottomInfoBoxVisible : 하단 정보바 전체와 도로명/목적지/행정동 정보 표시 여부
                true,  // isRerouteButtonVisible : 하단 정보바 경로 재탐색 버튼 표시 여부
                true // isStopButtonVisible : 하단 정보바 경로 안내 종료 버튼 표시 여부
            )
        )
    }

    // ── LongPress 경로 안내 기능 ──
    /**
     * 지도 LongPress 리스너를 등록한다.
     * DefaultScreen 진입 시 호출되어 mapTouchListener를 직접 설정.
     */
    private fun setupMapLongPressListener() {
        val mapView = navigationFragment.getVsmMapView() ?: return
        mapView.mapTouchListener = object : VsmSdkMapView.OnMapTouchListener {
            override fun onLongPress(event: MotionEvent?) {
                val vsmPoint = event?.let {
                    mapView.screenToWgs84(it.x.toInt(), it.y.toInt())
                } ?: return

                showRouteConfirmDialog(vsmPoint.longitude, vsmPoint.latitude)
            }
            override fun onDown(event: MotionEvent?) {}
            override fun onDoubleTap(event: MotionEvent?): Boolean = false
            override fun onSingleTap(event: MotionEvent?) {}
            override fun onFling(event1: MotionEvent?, event2: MotionEvent?, velocityX: Float, velocityY: Float) {}
            override fun onZoomChanged(prevLevel: Int, currentLevel: Int) {}
        }
    }

    /**
     * 경로 안내 확인 팝업을 표시한다.
     */
    private fun showRouteConfirmDialog(longitude: Double, latitude: Double) {
        android.app.AlertDialog.Builder(this)
            .setTitle("경로 안내 확인")
            .setMessage(
                "선택한 위치로 경로 안내를 시작하시겠습니까?\n\n위도: $latitude\n경도: $longitude"
            )
            .setPositiveButton("확인") { _, _ ->
                requestRouteToLongPressPoint(longitude, latitude)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    /**
     * LongPress 위치를 목적지로 경로 요청 (추천경로 + 고속도로우선).
     */
    private fun requestRouteToLongPressPoint(longitude: Double, latitude: Double) {
        buttonLayout.visibility = View.GONE

        val address = VSMCoordinates.getAddressOffline(longitude, latitude)
        val destination = WayPoint(address, MapPoint(longitude, latitude))
        val carOption = CarOption().apply {
            carType = TollCarType.Car
            oilType = CarOilType.Gasoline
            isHipassOn = true
        }
        navigationFragment.carOption = carOption

        navigationFragment.requestRoute(
            null,   // 출발지: 현재 위치
            null,   // 경유지: 없음
            destination,
            false,  // withoutPreview=false → 경로 선택 화면 표시
            object : RouteRequestListener {
                override fun onSuccess() {
                    Log.d(TAG, "LongPress 경로 요청 성공")
                }
                override fun onFail(errorCode: Int, errorMsg: String?) {
                    showToast("경로요청에 실패하였습니다 - $errorCode :: $errorMsg")
                    buttonLayout.visibility = View.VISIBLE
                }
            },
            requestRoutePlanTypes = arrayListOf(
                RoutePlanType.Traffic_Recommend,
                RoutePlanType.Traffic_Highway
            ),
            enableAutoFinishOnArrival = true
        )
    }
    private fun showToast(
        message: String,
        duration: Int = Toast.LENGTH_SHORT
    ) {
        this.runOnUiThread {
            Toast.makeText(baseContext, message, duration).show()
        }
    }


    override fun onBackPressed() {
        if (!navigationFragment.onBackKeyPressed()) {
            buttonLayout.visibility = View.VISIBLE
            stopButton.visibility = View.GONE
        }
    }

    fun initialize() {
        if (fusedLocationClient == null) {
            fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        }

        if (locationCallback == null) {
            locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    for (location in locationResult.locations) {
                        dbHelper.insertLocation(location, satelliteCount, location.provider)
                    }
                }
            }
        }

        if (gnssStatusCallback == null) {
            gnssStatusCallback = object : GnssStatus.Callback() {
                override fun onSatelliteStatusChanged(status: GnssStatus) {
                    satelliteCount = status.satelliteCount
                }
            }
        }

        if (locationManager == null) {
            locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        }
    }

    fun setLocation() {
        initialize()

        if (isLocationUpdating) return

        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            1000L
        ).setMinUpdateIntervalMillis(500L)
            .build()

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        fusedLocationClient?.requestLocationUpdates(
            locationRequest,
            locationCallback!!,
            Looper.getMainLooper()
        )

        isLocationUpdating = true

        if (!isGnssCallbackRegistered) {
            locationManager?.registerGnssStatusCallback(
                gnssStatusCallback!!,
                Handler.createAsync(Looper.getMainLooper())
            )
            isGnssCallbackRegistered = true
        }
    }

    fun stopLocation() {
        dbHelper.deleteAll()

        if (fusedLocationClient != null && locationCallback != null && isLocationUpdating) {
            fusedLocationClient?.removeLocationUpdates(locationCallback!!)
            isLocationUpdating = false
        }

        if (locationManager != null && gnssStatusCallback != null && isGnssCallbackRegistered) {
            locationManager?.unregisterGnssStatusCallback(gnssStatusCallback!!)
            isGnssCallbackRegistered = false
        }
    }

    private fun observeJammingZone() {
        navigationFragment.setGpsJammingToastEnabled(enabled = true)
        navigationFragment.gpsJammingCustomMessage = "<GPS가 불안정 합니다>"
    }

    private fun saveToDownloads(context: Context, filename: String, mimeType: String, data: ByteArray): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val fileUri = resolver.insert(collection, values)

        try {
            if (fileUri != null) {
                resolver.openOutputStream(fileUri)?.use { os ->
                    os.write(data)
                } ?: return false
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(fileUri, values, null, null)

                Log.d(TAG, "파일 저장 성공: $fileUri")
                return true
            }
        } catch (e: IOException) {
            Log.e(TAG, "파일 저장 실패: " + e.message)
        }
        return false
    }

    fun saveFileToDownloads(context: Context, filename: String?, content: String) {
        if (saveToDownloads(context, filename ?: "", "text/csv", content.toByteArray(StandardCharsets.UTF_8))) {
            Toast.makeText(context, "파일이 저장되었습니다: $filename", Toast.LENGTH_SHORT).show()
        }
        stopLocation()
    }

    fun saveRouteResultToDownloads(context: Context, filename: String, routeResult: RouteResult?) {
        val tempFile = File(context.cacheDir, filename)
        try {
            RouteResult.save(tempFile.absolutePath, routeResult)
            saveToDownloads(context, filename, "application/json", tempFile.readBytes())
        } catch (e: IOException) {
            Log.e(TAG, "routeResult 저장 실패: " + e.message)
        } finally {
            tempFile.delete()
        }
    }

    fun exportCsvFromDb(context: Context) {
        val cursor = dbHelper.allRows

        val headers = arrayOf<String>(
            "longitude", "latitude", "bearing", "speed", "Time (초)", "위성 수",
            "측위 방법", "HDOP", "맵 매칭 코드", "맵 매칭 경도", "맵 매칭 위도",
            "맵 매칭 각도", "실제 시간", "고도", "수직 각도", "provider",
            "activity type", "time (ms)"
        )

        val csv = StringBuilder()
        csv.append(TextUtils.join(",", headers)).append("\n")

        try {
            while (cursor.moveToNext()) {
                val row: MutableList<String?> = ArrayList()
                for (col in headers) {
                    val dbCol = columnNameToDbField(col)
                    val columnIndex: Int = cursor.getColumnIndexOrThrow(dbCol)

                    if (cursor.isNull(columnIndex)) {
                        row.add("")
                    } else if (isRealTypeColumn(col)) {
                        val value: Double = cursor.getDouble(columnIndex)
                        if (col == "longitude" || col == "latitude") {
                            row.add(String.format("%.15f", value))
                        } else {
                            row.add(String.format("%.10f", value))
                        }
                    } else {
                        row.add(cursor.getString(columnIndex))
                    }
                }
                csv.append(TextUtils.join(",", row)).append("\n")
            }
        } finally {
            cursor.close()
        }

        val formatted = TIMESTAMP_FORMATTER.format(LocalDateTime.now())
        saveFileToDownloads(context, "location_log_$formatted.csv", csv.toString())
    }

    private fun isRealTypeColumn(header: String): Boolean =
        header in REAL_TYPE_COLUMNS

    // 헤더명과 DB 컬럼명을 매핑
    private fun columnNameToDbField(header: String): String = when (header) {
        "Time (초)" -> "time_sec"
        "HDOP" -> "accuracy"
        "고도" -> "altitude"
        "수직 각도" -> "vertical_angle"
        "activity type" -> "activity_type"
        "time (ms)" -> "time_ms"
        "위성 수" -> "satellite_count"
        "맵 매칭 경도" -> "map_match_lng"
        "맵 매칭 위도" -> "map_match_lat"
        "맵 매칭 각도" -> "map_match_bearing"
        "맵 매칭 코드" -> "map_match_code"
        "실제 시간" -> "real_time"
        "측위 방법" -> "method"
        else -> header // 나머지는 동일
    }

    companion object {
        private const val TAG = "TMapUISDKSample"

        private const val CLIENT_ID = ""
        private const val API_KEY = "" //발급받은 KEY
        private const val USER_KEY = ""
        private const val DEVICE_KEY = ""

        private val TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
        private val GANGNAM_STATION = WayPoint("강남역", MapPoint(127.027813, 37.497999))
        private val GANGNAM_STATION_WITH_POI = WayPoint("강남역", MapPoint(127.027813, 37.497999), "280181", 5.toByte())
        private val REAL_TYPE_COLUMNS = setOf("longitude", "latitude", "bearing", "speed", "HDOP", "고도")
    }
}
